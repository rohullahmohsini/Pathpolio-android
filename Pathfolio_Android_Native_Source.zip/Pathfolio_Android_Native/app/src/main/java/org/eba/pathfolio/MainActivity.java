package org.eba.pathfolio;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

public class MainActivity extends AppCompatActivity {
    private static final int CREATE_PDF_REQUEST = 4101;
    private static final int FILE_PICKER_REQUEST = 4102;

    private WebView webView;
    private ValueCallback<Uri[]> filePickerCallback;
    private byte[] pendingPdf;
    private String pendingPdfName;

    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);

        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                             FileChooserParams params) {
                if (filePickerCallback != null) filePickerCallback.onReceiveValue(null);
                filePickerCallback = callback;
                Intent intent;
                try {
                    intent = params.createIntent();
                } catch (Exception e) {
                    intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    intent.setType("image/*");
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                }
                try {
                    startActivityForResult(intent, FILE_PICKER_REQUEST);
                } catch (ActivityNotFoundException e) {
                    filePickerCallback = null;
                    Toast.makeText(MainActivity.this, "No file picker is available", Toast.LENGTH_LONG).show();
                    return false;
                }
                return true;
            }
        });

        webView.addJavascriptInterface(new PdfBridge(), "PathfolioNative");
        webView.loadUrl("file:///android_asset/index.html");

        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override public void handleOnBackPressed() {
                if (webView.canGoBack()) webView.goBack();
                else finish();
            }
        });
    }

    public final class PdfBridge {
        @JavascriptInterface
        public void savePdf(String base64, String filename) {
            byte[] bytes = decode(base64);
            if (bytes == null) return;
            runOnUiThread(() -> launchSavePicker(bytes, filename));
        }

        @JavascriptInterface
        public void sharePdf(String base64, String filename, String title) {
            byte[] bytes = decode(base64);
            if (bytes == null) return;
            runOnUiThread(() -> shareNative(bytes, filename, title));
        }

        @JavascriptInterface
        public void openPdf(String base64, String filename) {
            byte[] bytes = decode(base64);
            if (bytes == null) return;
            runOnUiThread(() -> openNative(bytes, filename));
        }

        private byte[] decode(String value) {
            try {
                return Base64.decode(value, Base64.DEFAULT);
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this,
                        "The PDF data could not be read", Toast.LENGTH_LONG).show());
                return null;
            }
        }
    }

    private String safeName(String name) {
        String value = name == null ? "Pathfolio.pdf" : name.replaceAll("[\\\\/:*?\"<>|]", "_");
        if (!value.toLowerCase().endsWith(".pdf")) value += ".pdf";
        return value;
    }

    private File cachePdf(byte[] bytes, String filename) throws IOException {
        File directory = new File(getCacheDir(), "pdf");
        if (!directory.exists() && !directory.mkdirs()) throw new IOException("Could not create PDF cache");
        File file = new File(directory, safeName(filename));
        try (FileOutputStream stream = new FileOutputStream(file)) {
            stream.write(bytes);
        }
        return file;
    }

    private Uri contentUri(File file) {
        return FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", file);
    }

    private void launchSavePicker(byte[] bytes, String filename) {
        pendingPdf = bytes;
        pendingPdfName = safeName(filename);
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/pdf");
        intent.putExtra(Intent.EXTRA_TITLE, pendingPdfName);
        try {
            startActivityForResult(intent, CREATE_PDF_REQUEST);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, "No document app is available", Toast.LENGTH_LONG).show();
        }
    }

    private void shareNative(byte[] bytes, String filename, String title) {
        try {
            Uri uri = contentUri(cachePdf(bytes, filename));
            Intent intent = new Intent(Intent.ACTION_SEND);
            intent.setType("application/pdf");
            intent.putExtra(Intent.EXTRA_STREAM, uri);
            intent.putExtra(Intent.EXTRA_SUBJECT, title == null ? "Pathfolio PDF" : title);
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(intent, "Share or save PDF"));
        } catch (Exception e) {
            Toast.makeText(this, "Could not share PDF", Toast.LENGTH_LONG).show();
        }
    }

    private void openNative(byte[] bytes, String filename) {
        try {
            Uri uri = contentUri(cachePdf(bytes, filename));
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setDataAndType(uri, "application/pdf");
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(intent, "Open PDF to print"));
        } catch (ActivityNotFoundException e) {
            launchSavePicker(bytes, filename);
            Toast.makeText(this, "Install a PDF viewer to print. You can save the PDF now.", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "Could not open PDF", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == FILE_PICKER_REQUEST) {
            if (filePickerCallback != null) {
                Uri[] result = null;
                if (resultCode == Activity.RESULT_OK && data != null) {
                    if (data.getClipData() != null) {
                        int count = data.getClipData().getItemCount();
                        result = new Uri[count];
                        for (int i = 0; i < count; i++) result[i] = data.getClipData().getItemAt(i).getUri();
                    } else if (data.getData() != null) {
                        result = new Uri[]{data.getData()};
                    }
                }
                filePickerCallback.onReceiveValue(result);
                filePickerCallback = null;
            }
            return;
        }

        if (requestCode == CREATE_PDF_REQUEST) {
            if (resultCode == Activity.RESULT_OK && data != null && data.getData() != null && pendingPdf != null) {
                try (OutputStream stream = getContentResolver().openOutputStream(data.getData())) {
                    if (stream == null) throw new IOException("No output stream");
                    stream.write(pendingPdf);
                    Toast.makeText(this, "PDF saved successfully", Toast.LENGTH_LONG).show();
                } catch (Exception e) {
                    Toast.makeText(this, "Could not save PDF", Toast.LENGTH_LONG).show();
                }
            }
            pendingPdf = null;
            pendingPdfName = null;
        }
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.removeJavascriptInterface("PathfolioNative");
            webView.destroy();
        }
        super.onDestroy();
    }
}
